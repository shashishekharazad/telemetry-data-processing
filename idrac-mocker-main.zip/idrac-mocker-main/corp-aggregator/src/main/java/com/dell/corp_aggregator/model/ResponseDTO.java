package com.dell.corp_aggregator.model;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter
@Setter
public class ResponseDTO {
    private int statusCode;
    private String message;
    private LocalDateTime timestamp;
}
