package com.dell.corp_aggregator.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.dell.corp_aggregator.model.TelemetryData;
import com.dell.corp_aggregator.service.CorpAggregatorService;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/aggregator")
public class CorpAggregatorController {

    @Autowired
    private CorpAggregatorService service;
    @PostMapping("/telemetry")
    public ResponseEntity<String> receiveData(@RequestBody TelemetryData data) {
        return service.saveTelemetryData(data);
    }

    @PatchMapping("/patch")
    public ResponseEntity<String> updateData(@RequestBody TelemetryData data) {
        return service.saveTelemetryData(data);
    }

    @PostMapping("/msg")
    public String getMsg(@RequestBody String data) {
        return "Received: " + data;
    }

    @GetMapping("/msg")
    public String getStatus() {
        return "\nCorp Aggregator service is up and running!\n";
    }

    @GetMapping("/telemetry")
    public List<TelemetryData> getTelemetryData(@RequestParam(name = "nodeName", required = false) String nodeName) {
        if (nodeName != null && !nodeName.isEmpty()) {
            return service.getTelemetryByNode(nodeName);
        } else {
            return service.getTelemetryData();
        }
    }
}