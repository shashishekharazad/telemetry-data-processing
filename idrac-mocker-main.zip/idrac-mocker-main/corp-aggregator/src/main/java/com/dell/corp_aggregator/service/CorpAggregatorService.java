package com.dell.corp_aggregator.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.dell.corp_aggregator.model.TelemetryData;
import com.dell.corp_aggregator.repository.CorpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Service
public class CorpAggregatorService {
    @Autowired
    private CorpRepository repository;

    public List<TelemetryData> getTelemetryData() {
        return repository.findAll();
    }

    public ResponseEntity<String> saveTelemetryData(TelemetryData data) {
        try {
            repository.save(data);
            return new ResponseEntity<>("Telemetry data sent successfully!", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to send telemetry data!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public List<TelemetryData> getTelemetryByNode(String nodeName) {
        return repository.findByNode(nodeName);
    }

}
