package com.dell.corp_aggregator.repository;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.dell.corp_aggregator.model.TelemetryData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CorpRepository extends JpaRepository<TelemetryData, Long>{
     @Query("SELECT t FROM TelemetryData t WHERE t.node = :nodeName")
    List<TelemetryData> findByNode(@Param("nodeName") String nodeName);
}
