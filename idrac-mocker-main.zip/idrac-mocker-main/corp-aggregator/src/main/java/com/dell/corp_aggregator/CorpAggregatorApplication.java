package com.dell.corp_aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorpAggregatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorpAggregatorApplication.class, args);
	}

}
