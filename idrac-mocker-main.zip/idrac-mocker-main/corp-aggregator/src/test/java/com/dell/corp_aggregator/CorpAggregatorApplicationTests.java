package com.dell.corp_aggregator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorpAggregatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
