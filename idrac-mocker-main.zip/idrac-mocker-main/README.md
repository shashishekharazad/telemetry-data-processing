# iDRAC - Integrated Dell Remote Access Controller
This is the simulation of iDRAC and it has three services.
![alt text](https://eos2git.cec.lab.emc.com/shashi-azad/idrac-mocker/blob/main/Screenshot%202024-11-07%20151626.png)
## TelemetryAggregator
TelemetryAggregator that will mock the behavior of an iDRAC client in PowerEdge server. The data from this component will be used to mock the behavior of DCM (Dell Connectivity Module) client pushing telemetry data to Dell Corp Network.

## Corp. DMZ gateway
This service will be the entry point to the CORP Network this service will ensure only trusted devices can connect to the corp internal network.

## Corp. TelemetryAggregator
This Service will be taking in the data forwarded from the CORP DMZ gateway and storing it in the DB for future reference.

## Deployment on Kubernetes
Corp Telemetry Aggregator is deployed on Kubernetes using NGINX reverse proxy.
### Deployments
#### CorpAggrergator Deployment
Created a deployment that creates pods of the application and replicaset.
#### NGINX Deployment 
This creates the nginx deployment for the reverse proxy and it forward the traffic to corpaggregator.
### Services
#### CorpAggrergator Service
#### NGINX Service 

## Mutual TLS implementation
