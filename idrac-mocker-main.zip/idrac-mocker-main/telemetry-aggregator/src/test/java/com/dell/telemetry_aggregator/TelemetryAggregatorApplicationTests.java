package com.dell.telemetry_aggregator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelemetryAggregatorApplicationTests {

	@Test
	void contextLoads() {
   // TODO document why this method is empty
 }

}
