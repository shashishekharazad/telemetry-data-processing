package com.dell.telemetry_aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelemetryAggregatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelemetryAggregatorApplication.class, args);
	}

}
