package com.dell.telemetry_aggregator.controller;

import com.dell.telemetry_aggregator.model.TelemetryData;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dell.telemetry_aggregator.service.TelemetryService;

@RestController
@RequestMapping("/api")
public class TelemetryController {

    private final TelemetryService service = new TelemetryService();

    @GetMapping("/test")
    public String testApi() {
        return "\nTelemetry Aggregator Service is running!\n\n";
    }

    @PostMapping("/test")
    public void testTelemetryData(@RequestBody TelemetryData telemetryData) {
        service.sendTelemetryData(telemetryData);
        System.out.println("Telemetry Data sent successfully");
    }

    @PostMapping("/send")
    public void receiveTelemetryData(@RequestBody TelemetryData telemetryData) {
        service.sendTelemetryData(telemetryData);
    }
}
