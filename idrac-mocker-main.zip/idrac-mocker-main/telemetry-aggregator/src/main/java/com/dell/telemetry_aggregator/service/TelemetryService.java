package com.dell.telemetry_aggregator.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.dell.telemetry_aggregator.model.TelemetryData;
import org.springframework.web.client.RestClientException;

public class TelemetryService {
    private final RestTemplate restTemplate = new RestTemplate();
        private final String corpDmzUrl = "http://shashi-u24-vm.cec.delllabs.net";

    public void sendTelemetryData(TelemetryData data) {
        try {
            ResponseEntity<String> response = restTemplate.postForEntity(corpDmzUrl + "/aggregator/telemetry", data,
                    String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                response.getBody();
            } else {
                response.getStatusCode();
            }
        } catch (RestClientException e) {
            e.printStackTrace();
        }
    }
}
