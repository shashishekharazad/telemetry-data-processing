import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import './TelemetryData.css';

const TelemetryData = () => {
    const [latestDataByNode, setLatestDataByNode] = useState({});
    const API_URL = 'http://shashi-u24-vm.cec.delllabs.net/aggregator/telemetry';
    const navigate = useNavigate();

    useEffect(() => {
        const fetchTelemetryData = () => {
            fetch(API_URL)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    const latestData = {};
                    data.forEach(item => {
                        if (!latestData[item.node] || new Date(item.timestamp) > new Date(latestData[item.node].timestamp)) {
                            latestData[item.node] = item;
                        }
                    });
                    setLatestDataByNode(latestData);
                })
                .catch(error => console.error('Error fetching telemetry data:', error));
        };

        fetchTelemetryData(); // Initial fetch
        const interval = setInterval(fetchTelemetryData, 1000); // Fetch every 1 second

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, []);

    const handleNodeClick = (node) => {
        navigate(`/node/${node}`);
    };

    return (
        <div className="telemetry-container">
            {Object.keys(latestDataByNode).map(node => (
                <div key={node} className="node-section">
                    <button onClick={() => handleNodeClick(node)} className='node-button'>Node: {node}</button>
                    <div className="circle-container">
                        <div className="circle">
                            <h3>Temperature</h3>
                            <CircularProgressbar
                                value={latestDataByNode[node].temperature}
                                text={`${latestDataByNode[node].temperature} °C`}
                                styles={buildStyles({
                                    pathColor: '#8884d8',
                                    textColor: '#8884d8',
                                })}
                            />
                        </div>
                        <div className="circle">
                            <h3>Network Speed</h3>
                            <CircularProgressbar
                                value={latestDataByNode[node].networkSpeed}
                                text={`${latestDataByNode[node].networkSpeed}`}
                                styles={buildStyles({
                                    pathColor: '#82ca9d',
                                    textColor: '#82ca9d',
                                })}
                            />
                        </div>
                        <div className="circle">
                            <h3>Disk Utilization</h3>
                            <CircularProgressbar
                                value={latestDataByNode[node].diskUtilization}
                                text={`${latestDataByNode[node].diskUtilization}%`}
                                styles={buildStyles({
                                    pathColor: '#ffc658',
                                    textColor: '#ffc658',
                                })}
                            />
                        </div>
                        <div className="circle">
                            <h3>CPU Utilization</h3>
                            <CircularProgressbar
                                value={latestDataByNode[node].cpuUtilization}
                                text={`${latestDataByNode[node].cpuUtilization}%`}
                                styles={buildStyles({
                                    pathColor: '#ff7300',
                                    textColor: '#ff7300',
                                })}
                            />
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default TelemetryData;
